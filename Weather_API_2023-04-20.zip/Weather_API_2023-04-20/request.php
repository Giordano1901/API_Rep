<?php
$curl = curl_init();

$lat = -23.40;
$long = -46.35;

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.open-meteo.com/v1/forecast?latitude=' . $lat . '&longitude=' . $long . '&hourly=temperature_2m,precipitation_probability,weathercode&forecast_days=1&timezone=America%2FSao_Paulo',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$resultado = json_decode(curl_exec($curl));
// $response = curl_exec($curl);

curl_close($curl);

// echo "Latitude: " . $resultado -> latitude . "<br>" . "Longitude: " . $resultado -> longitude . "<br><br>";

$data = $resultado -> hourly -> time;
$temperatura = $resultado -> hourly -> temperature_2m;
$prob_precipitação = $resultado -> hourly -> precipitation_probability;
$cod_previsao = $resultado -> hourly -> weathercode;
// $data = substr($data, 11);

// $temp_array = array_combine($data, $temperatura);
// , $prob_precipitação, $temperatura

$temp_array = array_combine($data, $cod_previsao);

foreach($temp_array as $dia => $temp){
  if ($cod_previsao == 0) {
    $previsao = "Clear sky";
  } elseif ($cod_previsao == 1 || $cod_previsao ==  2 || $cod_previsao == 3) {
    $previsao = "Mainly clear, partly cloudy, and overcast";
  } elseif ($cod_previsao == 45 || $cod_previsao == 48) {
    $previsao = "Fog and depositing rime fog";
  } elseif ($cod_previsao == 51 || $cod_previsao == 53 || $cod_previsao == 55) {
    $previsao = "Drizzle: Light, moderate, and dense intensity";
  } elseif ($cod_previsao == 56 || $cod_previsao == 57) {
    $previsao = "Freezing Drizzle: Light and dense intensity";
  } elseif ($cod_previsao == 61 || $cod_previsao == 63 || $cod_previsao == 65) {
    $previsao = "Rain: Slight, moderate and heavy intensity";
  } elseif ($cod_previsao == 66 || $cod_previsao == 67) {
    $previsao = "Freezing Rain: Light and heavy intensity";
  } elseif ($cod_previsao == 71 || $cod_previsao == 73 || $cod_previsao == 75) {
    $previsao = "Snow fall: Slight, moderate, and heavy intensity";
  } elseif ($cod_previsao == 77) {
    $previsao = "Snow grains";
  } elseif ($cod_previsao == 80 || $cod_previsao == 81 || $cod_previsao == 82) {
    $previsao = "Rain showers: Slight, moderate, and violent";
  } elseif ($cod_previsao == 85 || $cod_previsao == 86) {
    $previsao = "Snow showers slight and heavy";
  } elseif ($cod_previsao == 95) {
    $previsao = "Thunderstorm: Slight or moderate";
  } elseif ($cod_previsao == 96 || $cod_previsao == 99) {
    $previsao = "Thunderstorm with slight and heavy hail";
  } else {
    $previsao = "Previsão não encontrada";
  }

  echo "<div class='prev'>
    <h4>Horário: " . substr($dia, 11) ."</h4>
    <p>" . $previsao . "</p>";
  

  echo "</div>";
}

// foreach($temp_array as $dia => $temp){
//     echo "<div class='prev'><h4> Horário: " . substr($dia, 11) . "</h4><p>Temperatura: " . $temp . "°C</p>";
    

//     echo "</div>";
// }

echo "<br><br><br>";

var_dump($resultado);

?>