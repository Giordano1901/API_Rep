<?php

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/stylee.css">
    <script src="JS/js.js"></script>
    <title>WEATHER_API_2023-04-19</title>
</head>
<body>
<main>
  <div class="title">
    <h1>Previsão do tempo - Open-Meteo API Test</h1>
  </div>
  <div class="contentDiv">
    <p>Para exibir informações climáticas em sua região basta aceitar as permissões de localização. <br> Em seguida clique no botão para iniciar a exibição.</p>
    <button onclick="getLocation()"><img src="ASSET/load_icon.svg" alt=""></button>
  </div>

  <div id="conteudo"></div>
</main>
</body>
</html>