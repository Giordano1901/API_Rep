function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else {
      alert("Geolocalização não é suportada por este navegador.");
    }
  }

  function showPosition(position) {
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    
    // Enviar dados para o arquivo PHP
    var xhr = new XMLHttpRequest();
    var url = "request.php";
    var params = "latitude=" + latitude + "&longitude=" + longitude;
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4 && xhr.status == 200) {
        // console.log(xhr.responseText);
        document.getElementById("conteudo").innerHTML = xhr.responseText;
      }
    };
    xhr.send(params);
}